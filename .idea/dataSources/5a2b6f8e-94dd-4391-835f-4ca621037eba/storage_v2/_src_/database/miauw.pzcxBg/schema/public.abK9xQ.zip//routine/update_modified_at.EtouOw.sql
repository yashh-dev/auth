create function update_modified_at() returns trigger
    language plpgsql
as
$$
BEGIN
    new.modified_at = current_timestamp;
    return new;
end;
$$;

alter function update_modified_at() owner to miauw_user;

